package com.example.roomie_2;

import android.support.v7.widget.RecyclerView;
import RecyclerView

public class imageAdapter extends RecyclerView.Adapter<ImageAdapter.ImageViewHolder> {
}
