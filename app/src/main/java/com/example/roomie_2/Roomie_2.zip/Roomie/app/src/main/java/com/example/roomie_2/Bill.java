package com.example.roomie_2;

public class Bill {

    public String from;
    public String to;
    public double amount;

    public Bill(String from,String to,double amount){
        this.from = from;
        this.to = to;
        this.amount = amount;
    }
    public Bill(){

    }

}
