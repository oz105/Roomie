package com.example.roomie_2;

public class ShopItem {
        public String name;
        public Float qty;

        public ShopItem(String name, Float Q) {
            this.name = name;
            this.qty = Q;
        }

        public ShopItem(){}
}
